

## 📌 Project 1: Movie & Book Recommendation System

An interactive recommendation system that:
- Asks the user for their favorite genre
- Lets them choose between Movies or Books
- Displays 10 suggestions with posters and brief descriptions

Built using:
- Python
- Google Colab
- Content-based Filtering
